# Final Project - Blackjack

## How to Run

### 1. Install backend dependencies
