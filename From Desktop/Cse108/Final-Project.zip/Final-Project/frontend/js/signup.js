document.getElementById("btnSignup").addEventListener("click", async ()=>{
  const username = document.getElementById("username").value;
  const password = document.getElementById("password").value;
  const passwordConfirm = document.getElementById("passwordConfirm").value;
  const res = await apiPost("/auth/signup", { username, password, passwordConfirm });
  if (res.error) {
    alert(res.error);
  } else {
    window.location = "login.html";
  }
});
