const urlParams = new URLSearchParams(window.location.search);
const gameId = urlParams.get("gameId");
const socket = io("/", { withCredentials: true });

let state = null;

socket.on("connect", ()=> {
  console.log("socket connected");
  socket.emit("join_game", { gameId: parseInt(gameId) });
});

socket.on("game_state", (s) => {
  state = s;
  renderState();
});

socket.on("chat", (m) => {
  appendChat(`${m.user}: ${m.text}`);
});

socket.on("error", (e) => {
  alert(e.message || JSON.stringify(e));
});

function appendChat(txt){
  const box = document.getElementById("chatBox");
  const el = document.createElement("div");
  el.innerText = txt;
  box.appendChild(el);
  box.scrollTop = box.scrollHeight;
}

document.getElementById("btnSend").addEventListener("click", () => {
  const t = document.getElementById("chatInput").value;
  if (!t) return;
  socket.emit("chat", { gameId: parseInt(gameId), text: t });
  document.getElementById("chatInput").value = "";
});

document.getElementById("btnBet").addEventListener("click", ()=> {
  const amt = parseInt(document.getElementById("betAmount").value || "0");
  socket.emit("place_bet", { gameId: parseInt(gameId), amount: amt });
});

document.getElementById("btnReady").addEventListener("click", ()=> {
  socket.emit("player_ready", { gameId: parseInt(gameId) });
});

document.getElementById("btnStart").addEventListener("click", ()=> {
  socket.emit("start_game", { gameId: parseInt(gameId) });
});

document.getElementById("btnHit").addEventListener("click", ()=> {
  socket.emit("hit", { gameId: parseInt(gameId) });
});

document.getElementById("btnStand").addEventListener("click", ()=> {
  socket.emit("stand", { gameId: parseInt(gameId) });
});

function cardLabel(c){
  if(!c) return "";
  return `${c.r}${c.s}`;
}

function renderState(){
  // room title
  document.getElementById("roomTitle").innerText = `Game Room #${gameId} — ${state.status || ""}`;

  // players
  const list = document.getElementById("playerList");
  list.innerHTML = "";
  for (const [pid, p] of Object.entries(state.players || {})){
    const li = document.createElement("li");
    li.className = "player-item";
    const name = document.createElement("div");
    name.innerHTML = `<strong>${p.username}</strong> <small class="muted">[${p.status}]</small>`;
    const right = document.createElement("div");
    right.innerHTML = `Bet: ${p.bet || 0} <br/>Bal: ${p.balance || "-"}`;
    const hand = document.createElement("div");
    hand.className = "card-row";
    (p.hand || []).forEach(c=>{
      const cd = document.createElement("div");
      cd.className = "card";
      cd.innerText = cardLabel(c);
      hand.appendChild(cd);
    });
    const wrap = document.createElement("div");
    wrap.appendChild(name);
    wrap.appendChild(hand);
    wrap.appendChild(right);
    li.appendChild(wrap);
    list.appendChild(li);
  }

  // dealer
  const drow = document.getElementById("dealerCards");
  drow.innerHTML = "";
  (state.dealer?.hand || []).forEach(c=>{
    const cd = document.createElement("div");
    cd.className = "card";
    cd.innerText = cardLabel(c);
    drow.appendChild(cd);
  });

  // chat
  const chatBox = document.getElementById("chatBox");
  chatBox.innerHTML = "";
  (state.chat || []).forEach(m=>{
    appendChat(`${m.user}: ${m.text}`);
  });
}
