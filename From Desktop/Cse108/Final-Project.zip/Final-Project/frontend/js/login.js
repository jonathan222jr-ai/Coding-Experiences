document.getElementById("btnLogin").addEventListener("click", async ()=>{
  const username = document.getElementById("username").value;
  const password = document.getElementById("password").value;
  const res = await apiPost("/auth/login", { username, password });
  if (res.error) {
    alert(res.error);
  } else {
    window.location = "lobby.html";
  }
});
