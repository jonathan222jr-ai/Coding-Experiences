const API_BASE = "";

async function apiPost(endpoint, data) {
  const res = await fetch(endpoint, {
    method: "POST",
    credentials: "include",
    headers: {"Content-Type": "application/json"},
    body: JSON.stringify(data)
  });
  return await res.json();
}

async function apiGet(endpoint) {
  const res = await fetch(endpoint, {
    credentials: "include"
  });
  return await res.json();
}
