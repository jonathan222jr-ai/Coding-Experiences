from fastapi import APIRouter, WebSocket
import random

router = APIRouter()

active_players = {}

def draw_card():
    return random.choice(["A","2","3","4","5","6","7","8","9","10","J","Q","K"])

@router.websocket("/ws/game")
async def game_socket(ws: WebSocket):
    await ws.accept()

    player_id = id(ws)
    active_players[player_id] = ws

    try:
        while True:
            msg = await ws.receive_json()

            if msg["action"] == "hit":
                card = draw_card()
                await ws.send_json({"card": card})

            if msg["action"] == "stand":
                await ws.send_json({"result": "You stood."})

    except:
        del active_players[player_id]
