# Bulletproof app.py for Flask + SQLAlchemy + Flask-Login + Admin
# Includes:
# ✅ Absolute database path
# ✅ Automatic instance/ directory creation
# ✅ Automatic database file creation
# ✅ Logging of resolved DB path
# ✅ Clean create_app structure

from flask import Flask, render_template, redirect, url_for, flash, request
from flask_sqlalchemy import SQLAlchemy
from flask_login import LoginManager, login_user, login_required, logout_user, current_user
from werkzeug.security import generate_password_hash, check_password_hash
from flask_admin import Admin
from flask_admin.contrib.sqla import ModelView
from models import db, User, Course, Enrollment
from forms import LoginForm
from datetime import datetime
import os

def create_app():
    # ----------------------------------------------------------
    # ✅ Initialize Flask
    # ----------------------------------------------------------
    app = Flask(__name__)
    app.config['SECRET_KEY'] = os.environ.get('FLASK_SECRET', 'dev-secret')

    # ----------------------------------------------------------
    # ✅ Build absolute path to instance/database.db
    # ----------------------------------------------------------
    project_root = os.path.abspath(os.path.dirname(__file__))
    instance_dir = os.path.join(project_root, 'instance')
    db_path = os.path.join(instance_dir, 'database.db')

    # ----------------------------------------------------------
    # ✅ Ensure instance/ folder exists
    # ----------------------------------------------------------
    if not os.path.exists(instance_dir):
        os.makedirs(instance_dir)
        print(f"📁 Created missing folder: {instance_dir}")

    # ----------------------------------------------------------
    # ✅ Ensure database.db file exists
    # ----------------------------------------------------------
    if not os.path.exists(db_path):
        open(db_path, 'a').close()
        print(f"🆕 Created new empty database file: {db_path}")

    # ----------------------------------------------------------
    # ✅ Configure SQLAlchemy with absolute path
    # ----------------------------------------------------------
    db_uri = f"sqlite:///{db_path}"
    app.config['SQLALCHEMY_DATABASE_URI'] = db_uri
    app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
    print(f"✅ Using database at: {db_uri}")

    db.init_app(app)

    # ----------------------------------------------------------
    # ✅ Flask-Login Setup
    # ----------------------------------------------------------
    login_manager = LoginManager()
    login_manager.login_view = 'login'
    login_manager.init_app(app)

    @login_manager.user_loader
    def load_user(user_id):
        return User.query.get(int(user_id))

    # ----------------------------------------------------------
    # ✅ Flask-Admin Setup
    # ----------------------------------------------------------
    admin = Admin(app, name='ACME Admin', template_mode='bootstrap3')

    class AdminModelView(ModelView):
        def is_accessible(self):
            return current_user.is_authenticated and current_user.role == 'admin'

    admin.add_view(AdminModelView(User, db.session))
    admin.add_view(AdminModelView(Course, db.session))
    admin.add_view(AdminModelView(Enrollment, db.session))

    # ----------------------------------------------------------
    # ✅ Routes
    # ----------------------------------------------------------
    @app.route('/')
    def index():
        if current_user.is_authenticated:
            if current_user.role == 'student':
                return redirect(url_for('student_dashboard'))
            if current_user.role == 'teacher':
                return redirect(url_for('teacher_dashboard'))
            if current_user.role == 'admin':
                return redirect('/admin')
        return redirect(url_for('login'))

    @app.route('/login', methods=['GET', 'POST'])
    def login():
        form = LoginForm()
        if form.validate_on_submit():
            user = User.query.filter_by(username=form.username.data).first()
            if user and check_password_hash(user.password_hash, form.password.data):
                login_user(user)
                return redirect(url_for('index'))
            flash('Invalid username or password', 'danger')
        return render_template('login.html', form=form)

    @app.route('/logout')
    @login_required
    def logout():
        logout_user()
        flash('Signed out.', 'info')
        return redirect(url_for('login'))

    # ----------------------------------------------------------
    # ✅ Student Dashboard
    # ----------------------------------------------------------
    @app.route('/student')
    @login_required
    def student_dashboard():
        if current_user.role != 'student':
            flash('Unauthorized', 'danger')
            return redirect(url_for('index'))
        courses = Course.query.all()
        my_enrollments = [e.course for e in current_user.enrollments]
        return render_template('student_dashboard.html', courses=courses, my_enrollments=my_enrollments)

    @app.route('/student/enroll/<int:course_id>')
    @login_required
    def enroll(course_id):
        if current_user.role != 'student':
            flash('Unauthorized', 'danger')
            return redirect(url_for('index'))
        course = Course.query.get_or_404(course_id)
        cur_count = len(course.enrollments)
        if cur_count >= course.capacity:
            flash('Course is full', 'warning')
        else:
            existing = Enrollment.query.filter_by(student_id=current_user.id, course_id=course.id).first()
            if existing:
                flash('Already enrolled', 'info')
            else:
                e = Enrollment(student_id=current_user.id, course_id=course.id)
                db.session.add(e)
                db.session.commit()
                flash('Enrolled successfully', 'success')
        return redirect(url_for('student_dashboard'))

    # ----------------------------------------------------------
    # ✅ Teacher Routes
    # ----------------------------------------------------------
    @app.route('/teacher')
    @login_required
    def teacher_dashboard():
        if current_user.role != 'teacher':
            flash('Unauthorized', 'danger')
            return redirect(url_for('index'))
        courses = Course.query.filter_by(teacher_id=current_user.id).all()
        return render_template('teacher_dashboard.html', courses=courses)

    @app.route('/teacher/course/<int:course_id>', methods=['GET', 'POST'])
    @login_required
    def teacher_course(course_id):
        if current_user.role != 'teacher':
            flash('Unauthorized', 'danger')
            return redirect(url_for('index'))
        course = Course.query.get_or_404(course_id)
        if course.teacher_id != current_user.id:
            flash('Unauthorized for that course', 'danger')
            return redirect(url_for('teacher_dashboard'))
        if request.method == 'POST':
            for key, val in request.form.items():
                if key.startswith('grade_'):
                    enrollment_id = int(key.split('_')[1])
                    e = Enrollment.query.get(enrollment_id)
                    if e:
                        e.grade = val
            db.session.commit()
            flash('Grades updated', 'success')
        return render_template('teacher_course.html', course=course)

    # ----------------------------------------------------------
    # ✅ Template context injection
    # ----------------------------------------------------------
    @app.context_processor
    def inject_year():
        return {'year': datetime.now().year, 'time': datetime.now().timestamp()}

    return app

# --------------------------------------------------------------
# ✅ Run App
# --------------------------------------------------------------
if __name__ == '__main__':
    app = create_app()
    with app.app_context():
        db.create_all()
    app.run(debug=True)
