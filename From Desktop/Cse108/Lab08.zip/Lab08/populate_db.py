from werkzeug.security import generate_password_hash
from app import create_app, db, User, Course

app = create_app()

with app.app_context():
    db_uri = app.config["SQLALCHEMY_DATABASE_URI"]
    print("✅ Flask is using this DB:", db_uri)

    db.create_all()

    users_data = [
        {'username': 'admin', 'password': 'adminpass', 'role': 'admin'},
        {'username': 'Dr_Jonathan', 'password': 'teachpass', 'role': 'teacher'},
        {'username': 'Jonathan', 'password': 'studpass', 'role': 'student'}
    ]

    for u in users_data:
        if not User.query.filter_by(username=u['username']).first():
            user = User(
                username=u['username'],
                password_hash=generate_password_hash(u['password'], method='pbkdf2:sha256'),
                role=u['role']
            )
            db.session.add(user)

    db.session.commit()
    print("✅ Users added (if they did not exist)")

    teacher = User.query.filter_by(username='Dr_Jonathan').first()
    if teacher:
        if not Course.query.filter_by(name='CSE 162').first():
            course = Course(name='CSE 162', capacity=30, teacher_id=teacher.id)
            db.session.add(course)
            db.session.commit()
            print("✅ Course 'CSE 162' added")
        else:
            print("ℹ️ Course 'CSE 162' already exists")
    else:
        print("❌ Teacher Dr_Jonathan not found; cannot add course")

print("🎉 Database setup/update complete!")
