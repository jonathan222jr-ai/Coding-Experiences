const API_BASE = "http://127.0.0.1:5000";

// GET /grades/<student>
document.getElementById("getGradeBtn").addEventListener("click", async () => {
  const name = document.getElementById("studentName").value.trim();
  const result = document.getElementById("gradeResult");
  if (!name) return (result.textContent = "Enter a student name.");

  try {
    const res = await fetch(`${API_BASE}/grades/${encodeURIComponent(name)}`);
    const data = await res.json();
    if (res.ok) {
      result.textContent = `${name}: ${data[name]}`;
    } else {
      result.textContent = data.error || "Student not found.";
    }
  } catch (err) {
    result.textContent = "Error connecting to server.";
  }
});

// GET /grades
document.getElementById("getAllBtn").addEventListener("click", async () => {
  try {
    const res = await fetch(`${API_BASE}/grades`);
    const data = await res.json();
    const tbody = document.querySelector("#gradesTable tbody");
    tbody.innerHTML = "";
    for (const [name, grade] of Object.entries(data)) {
      const row = `<tr><td>${name}</td><td>${grade}</td></tr>`;
      tbody.insertAdjacentHTML("beforeend", row);
    }
  } catch (err) {
    alert("Error fetching grades");
  }
});

// POST /grades
document.getElementById("addBtn").addEventListener("click", async () => {
  const name = document.getElementById("newName").value.trim();
  const grade = parseFloat(document.getElementById("newGrade").value);
  if (!name || isNaN(grade)) return alert("Enter a valid name and grade.");

  try {
    const res = await fetch(`${API_BASE}/grades`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ name, grade })
    });
    const data = await res.json();
    alert(`Added: ${Object.keys(data)[0]} = ${Object.values(data)[0]}`);
  } catch {
    alert("Error adding grade");
  }
});

// PUT /grades/<name>
document.getElementById("editBtn").addEventListener("click", async () => {
  const name = document.getElementById("editName").value.trim();
  const grade = parseFloat(document.getElementById("editGrade").value);
  if (!name || isNaN(grade)) return alert("Enter a valid name and grade.");

  try {
    const res = await fetch(`${API_BASE}/grades/${encodeURIComponent(name)}`, {
      method: "PUT",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ grade })
    });
    const data = await res.json();
    alert(res.ok ? `Updated: ${Object.keys(data)[0]} = ${Object.values(data)[0]}` : data.error);
  } catch {
    alert("Error updating grade");
  }
});

// DELETE /grades/<name>
document.getElementById("deleteBtn").addEventListener("click", async () => {
  const name = document.getElementById("deleteName").value.trim();
  if (!name) return alert("Enter a name to delete.");

  try {
    const res = await fetch(`${API_BASE}/grades/${encodeURIComponent(name)}`, {
      method: "DELETE"
    });
    const data = await res.json();
    alert(res.ok ? `Deleted ${Object.keys(data)[0]}` : data.error);
  } catch {
    alert("Error deleting grade");
  }
});
