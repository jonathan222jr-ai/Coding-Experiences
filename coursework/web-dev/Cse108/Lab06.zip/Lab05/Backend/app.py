from flask import Flask, request, jsonify
from flask_cors import CORS

app = Flask(__name__)
CORS(app)  # ✅ allow your frontend JS to talk to Flask

# In-memory data store
grades = {
    "Alice": 95.0,
    "Bob": 87.5,
    "Charlie": 78.0
}

@app.route("/grades", methods=["GET"])
def get_all_grades():
    return jsonify(grades)

@app.route("/grades/<string:name>", methods=["GET"])
def get_grade(name):
    if name in grades:
        return jsonify({name: grades[name]})
    return jsonify({"error": "Student not found"}), 404

@app.route("/grades", methods=["POST"])
def add_grade():
    data = request.get_json()
    name = data.get("name")
    grade = data.get("grade")
    if not name or grade is None:
        return jsonify({"error": "Invalid input"}), 400
    grades[name] = grade
    return jsonify({name: grade}), 201

@app.route("/grades/<string:name>", methods=["PUT"])
def update_grade(name):
    if name not in grades:
        return jsonify({"error": "Student not found"}), 404
    data = request.get_json()
    grade = data.get("grade")
    grades[name] = grade
    return jsonify({name: grade})

@app.route("/grades/<string:name>", methods=["DELETE"])
def delete_grade(name):
    if name in grades:
        deleted = grades.pop(name)
        return jsonify({name: deleted})
    return jsonify({"error": "Student not found"}), 404

if __name__ == "__main__":
    app.run(debug=True)
