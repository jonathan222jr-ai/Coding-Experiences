from flask_sqlalchemy import SQLAlchemy
from flask_login import UserMixin

db = SQLAlchemy()

class User(db.Model, UserMixin):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(80), unique=True, nullable=False)
    password_hash = db.Column(db.String(200), nullable=False)
    role = db.Column(db.String(20), nullable=False)
    enrollments = db.relationship('Enrollment', back_populates='student', cascade='all, delete-orphan')
    courses = db.relationship('Course', back_populates='teacher', foreign_keys='Course.teacher_id')

    def __repr__(self):
        return f"<User {self.username} ({self.role})>"

class Course(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(120), nullable=False)
    capacity = db.Column(db.Integer, nullable=False, default=30)
    teacher_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=True)
    teacher = db.relationship('User', back_populates='courses', foreign_keys=[teacher_id])
    enrollments = db.relationship('Enrollment', back_populates='course', cascade='all, delete-orphan')

    def __repr__(self):
        return f"<Course {self.name}>"

class Enrollment(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    student_id = db.Column(db.Integer, db.ForeignKey('user.id'))
    course_id = db.Column(db.Integer, db.ForeignKey('course.id'))
    grade = db.Column(db.String(10))
    student = db.relationship('User', back_populates='enrollments', foreign_keys=[student_id])
    course = db.relationship('Course', back_populates='enrollments', foreign_keys=[course_id])

    def __repr__(self):
        return f"<Enrollment s:{self.student_id} c:{self.course_id}>"
