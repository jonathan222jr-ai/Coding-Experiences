from flask import Flask, render_template, redirect, url_for, request, flash
from flask_sqlalchemy import SQLAlchemy
from flask_login import LoginManager, login_user, logout_user, login_required, current_user, UserMixin
from flask_admin import Admin
from flask_admin.contrib.sqla import ModelView
from werkzeug.security import generate_password_hash, check_password_hash
from forms import LoginForm, GradeForm
import os

app = Flask(__name__)
app.config['SECRET_KEY'] = 'dev-secret'

# -----------------------
# DATABASE SETUP
# -----------------------
basedir = os.path.abspath(os.path.dirname(__file__))
instance_path = os.path.join(basedir, 'instance')

# Make sure instance folder exists
if not os.path.exists(instance_path):
    os.makedirs(instance_path)

# Absolute path to the database file
db_path = os.path.join(instance_path, 'database.db')
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///' + db_path
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

db = SQLAlchemy(app)
login = LoginManager(app)
login.login_view = 'login'

# -----------------------
# MODELS
# -----------------------
class User(db.Model, UserMixin):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(80), unique=True, nullable=False)
    password_hash = db.Column(db.String(200), nullable=False)
    role = db.Column(db.String(20), nullable=False)

    def set_password(self, pw):
        # Fixed: use PBKDF2 to avoid scrypt issue
        self.password_hash = generate_password_hash(pw, method='pbkdf2:sha256')

    def check_password(self, pw):
        return check_password_hash(self.password_hash, pw)


class Course(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(120), nullable=False)
    time = db.Column(db.String(120))
    capacity = db.Column(db.Integer, default=0)
    teacher_id = db.Column(db.Integer, db.ForeignKey("user.id"))
    teacher = db.relationship('User', foreign_keys=[teacher_id])
    enrollments = db.relationship('Enrollment', back_populates='course', cascade='all, delete-orphan')


class Enrollment(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    student_id = db.Column(db.Integer, db.ForeignKey("user.id"))
    course_id = db.Column(db.Integer, db.ForeignKey("course.id"))
    grade = db.Column(db.Integer, nullable=True)
    student = db.relationship('User', foreign_keys=[student_id])
    course = db.relationship('Course', back_populates='enrollments')


# Relationship for students to find their enrollments
User.enrollments = db.relationship("Enrollment", back_populates="student", cascade="all, delete-orphan", foreign_keys=[Enrollment.student_id])


@login.user_loader
def load_user(id):
    return User.query.get(int(id))


# -----------------------
# ROUTES
# -----------------------
@app.route("/")
def index():
    if current_user.is_authenticated:
        if current_user.role == "student":
            return redirect(url_for("student_dashboard"))
        if current_user.role == "teacher":
            return redirect(url_for("teacher_dashboard"))
        if current_user.role == "admin":
            return redirect(url_for("admin_dashboard"))
    return redirect(url_for("login"))


@app.route("/login", methods=["GET","POST"])
def login():
    form = LoginForm()
    if form.validate_on_submit():
        u = User.query.filter_by(username=form.username.data).first()
        if u and u.check_password(form.password.data):
            login_user(u)
            return redirect(url_for("index"))
        flash("Invalid username or password","danger")
    return render_template("login.html", form=form)


@app.route("/logout")
@login_required
def logout():
    logout_user()
    return redirect(url_for("login"))


# -----------------------
# STUDENT DASHBOARD
# -----------------------
@app.route("/student")
@login_required
def student_dashboard():
    if current_user.role != "student":
        return redirect(url_for("index"))

    courses = Course.query.all()
    my_courses = [e.course for e in current_user.enrollments]
    course_counts = {c.id: len(c.enrollments) for c in courses}

    return render_template("student_dashboard.html",
                           courses=courses,
                           enrolled=my_courses,
                           course_counts=course_counts)


@app.route("/student/signup/<int:course_id>", methods=["POST"])
@login_required
def signup_course(course_id):
    if current_user.role != "student":
        return redirect(url_for("index"))

    course = Course.query.get_or_404(course_id)
    enrolled_count = len(course.enrollments)

    if enrolled_count >= course.capacity:
        flash("Course is full.","warning")
    else:
        exists = Enrollment.query.filter_by(student_id=current_user.id, course_id=course_id).first()
        if exists:
            flash("You are already enrolled.", "info")
        else:
            db.session.add(Enrollment(student_id=current_user.id, course_id=course.id))
            db.session.commit()
            flash("Successfully enrolled!", "success")

    return redirect(url_for("student_dashboard"))


# -----------------------
# TEACHER DASHBOARD
# -----------------------
@app.route("/teacher")
@login_required
def teacher_dashboard():
    if current_user.role != "teacher":
        return redirect(url_for("index"))

    courses = Course.query.filter_by(teacher_id=current_user.id).all()
    return render_template("teacher_dashboard.html", courses=courses)


@app.route("/teacher/course/<int:course_id>", methods=["GET","POST"])
@login_required
def teacher_course(course_id):
    if current_user.role != "teacher":
        return redirect(url_for("index"))

    course = Course.query.get_or_404(course_id)

    if course.teacher_id != current_user.id:
        flash("You do not teach this course.","danger")
        return redirect(url_for("teacher_dashboard"))

    form = GradeForm()

    if form.validate_on_submit():
        e = Enrollment.query.get(form.enrollment_id.data)
        e.grade = form.grade.data
        db.session.commit()
        flash("Grade updated.","success")
        return redirect(url_for("teacher_course", course_id=course.id))

    return render_template("teacher_course.html", course=course, form=form)


# -----------------------
# ADMIN
# -----------------------
admin = Admin(app, name="Lab08 Admin", template_mode="bootstrap3")

@app.route("/admin")
@login_required
def admin_dashboard():
    if current_user.role != "admin":
        return redirect(url_for("index"))
    return render_template("admin.html")


# -----------------------
# CREATE DATABASE IF NOT EXISTS
# -----------------------
if not os.path.exists(db_path):
    db.create_all()

# Add admin views
admin.add_view(ModelView(User, db.session))
admin.add_view(ModelView(Course, db.session))
admin.add_view(ModelView(Enrollment, db.session))


# -----------------------
if __name__ == "__main__":
    app.run(debug=True)
