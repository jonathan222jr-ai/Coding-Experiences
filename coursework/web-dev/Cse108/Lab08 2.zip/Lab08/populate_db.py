from app import app, db, User, Course, Enrollment

# Wrap everything in app context
with app.app_context():

    # Reset database
    db.drop_all()
    db.create_all()

    # ------------------
    # Create users
    # ------------------
    students = ["Jose", "Betty", "John", "Li", "Nancy", "Mindy", "Aditya", "YiWen"]
    teachers = ["Ralph", "Susan", "Ammon"]

    for name in students:
        u = User(username=name, role="student")
        u.set_password("password")
        db.session.add(u)

    for t in teachers:
        u = User(username=t, role="teacher")
        u.set_password("password")
        db.session.add(u)

    admin = User(username="admin", role="admin")
    admin.set_password("admin")
    db.session.add(admin)

    db.session.commit()

    def get_user(name):
        return User.query.filter_by(username=name).first()

    # ------------------
    # Create courses
    # ------------------
    c1 = Course(name="Math 101", teacher=get_user("Ralph"), time="MWF 10:00–10:50 AM", capacity=8)
    c2 = Course(name="Physics 121", teacher=get_user("Susan"), time="TR 11:00–11:50 AM", capacity=10)
    c3 = Course(name="CS 106", teacher=get_user("Ammon"), time="MWF 2:00–2:50 PM", capacity=10)
    c4 = Course(name="CS 162", teacher=get_user("Ammon"), time="TR 3:00–3:50 PM", capacity=4)

    db.session.add_all([c1, c2, c3, c4])
    db.session.commit()

    # Helper to enroll students
    def enroll(student_name, course, grade):
        student = get_user(student_name)
        db.session.add(Enrollment(student_id=student.id, course_id=course.id, grade=grade))

    # Enroll students
    enroll("Jose", c1, 92)
    enroll("Betty", c1, 65)
    enroll("John", c1, 86)
    enroll("Li", c1, 77)

    enroll("Nancy", c2, 53)
    enroll("Li", c2, 85)
    enroll("Mindy", c2, 94)
    enroll("John", c2, 91)
    enroll("Betty", c2, 88)

    enroll("Aditya", c3, 93)
    enroll("YiWen", c3, 85)
    enroll("Nancy", c3, 57)
    enroll("Mindy", c3, 68)

    enroll("Aditya", c4, 99)
    enroll("Nancy", c4, 87)
    enroll("YiWen", c4, 92)
    enroll("John", c4, 67)

    db.session.commit()
    print("Database populated successfully!")
